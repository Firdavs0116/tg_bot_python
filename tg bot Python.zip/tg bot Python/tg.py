import telebot
from telebot import types
import time
import random

bot = telebot.TeleBot("6821040399:AAEHRjALNFNWXBWhBhQwRZASS2YAmZ75UQ8", parse_mode=None)

CHANNEL_ID = "@Kompyuter va ilm🧑‍💻"

ongoing_competitions = {}

@bot.message_handler(commands=['start'])
def send_welcome(message):
    if not user_is_subscribed(message.from_user.id):
        markup = types.InlineKeyboardMarkup()
        join_channel_btn = types.InlineKeyboardButton(text="Kanalga a'zo bo'lish", url="https://t.me/RoboContests_masalalar_yechimlar")
        verify_subscription_btn = types.InlineKeyboardButton(text="Tekshirish", callback_data="verify_subscription")
        markup.add(join_channel_btn, verify_subscription_btn)
        bot.send_message(message.chat.id, "Botdan foydalanishni davom etish uchun kanalga a'zo bo'ling va /start buyrug'ini botga yuboring.", reply_markup=markup)
    else:
        send_menu(message)
        bot.send_message(message.chat.id, "Assalomu alekum botimizga xush kelibsiz foydalanishni boshlash uchun /start ni bosing☺")

def user_is_subscribed(user_id):
    try:
        member = bot.get_chat_member(CHANNEL_ID, user_id)
        return member.status in ['member', 'administrator', 'creator']
    except:
        return False

def send_menu(message):
    markup = types.ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
    bellashuv_btn = types.KeyboardButton("⚔ Bellashuv")
    reyting_btn = types.KeyboardButton("📊 Reyting")
    sozlamalar_btn = types.KeyboardButton("⚙️ Sozlamalar")
    mashqlar_btn = types.KeyboardButton("😊 Mashqlar")
    lugat_btn = types.KeyboardButton("📚 So'zlar")
    markup.add(bellashuv_btn, reyting_btn, mashqlar_btn, lugat_btn, sozlamalar_btn)
    bot.send_message(message.chat.id, "Menudan birini tanlang:", reply_markup=markup)

@bot.message_handler(func=lambda message: message.text == "⚔ Bellashuv")
def bellashuv_menu(message):
    markup = types.InlineKeyboardMarkup()
    random_opponent_btn = types.InlineKeyboardButton("Random Odam", callback_data='random_opponent')
    specific_opponent_btn = types.InlineKeyboardButton("Do'st bilan bellashuv", callback_data='specific_opponent')
    markup.add(random_opponent_btn, specific_opponent_btn)
    bot.send_message(message.chat.id, "Kim bilan bellashmoqchisiz?", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data in ['random_opponent', 'specific_opponent'])
def handle_bellashuv(call):
    if call.data == 'random_opponent':
        opponent_id = random.choice([user_id for user_id in range(1000, 9999)])
        start_competition(call.message, call.from_user.id, opponent_id)
    elif call.data == 'specific_opponent':
        bot.send_message(call.message.chat.id, "Do'stingizni tanlang yoki u sizni chaqirishi kerak.")

@bot.callback_query_handler(func=lambda call: call.data == 'verify_subscription')
def verify_subscription(call):
    if user_is_subscribed(call.from_user.id):
        bot.answer_callback_query(call.id, "Siz kanalga a'zo bo'lgansiz!")
        send_menu(call.message)
    else:
        bot.answer_callback_query(call.id, "Siz hali kanalga a'zo bo'lmagansiz. Kanalga a'zo bo'ling va qaytadan tekshirib ko'ring.")
        bot.send_message(call.message.chat.id, "Botdan foydalanishni davom etish uchun kanalga a'zo bo'ling va /start buyrug'ini botga yuboring.")

def start_competition(message, user1_id, user2_id):
    ongoing_competitions[user1_id] = {"opponent": user2_id, "start_time": time.time()}
    bot.send_message(user1_id, "Bellashuv boshlandi! Savollarga javob bering.")
    bot.send_message(user2_id, "Bellashuv boshlandi! Savollarga javob bering.")

def finalize_competition(user_id):
    competition = ongoing_competitions.get(user_id)
    if competition:
        opponent_id = competition['opponent']
        user_time = time.time() - competition['start_time']
        user_score = random.randint(0, 20)
        opponent_score = random.randint(0, 20) 

        if user_score > opponent_score:
            winner_id = user_id
        elif opponent_score > user_score:
            winner_id = opponent_id
            if user_time < (time.time() - competition['start_time']):
                winner_id = user_id
            else:
                winner_id = opponent_id

        bot.send_message(winner_id, "Siz g'olib bo'ldingiz!")
        bot.send_message(opponent_id, "Siz yutqazdingiz!")
        del ongoing_competitions[user_id]
        del ongoing_competitions[opponent_id]

@bot.message_handler(func=lambda message: message.text == "📚 So'zlar")
def send_words(message):
    bot.reply_to(message, "Bu yerda lug'at va mashqlarni topishingiz mumkin.")

@bot.message_handler(func=lambda message: message.text == "📊 Reyting")
def send_reyting(message):
    bot.reply_to(message, "Bu yerda reytingni ko'rishingiz mumkin.")

@bot.message_handler(func=lambda message: message.text == "😊 Mashqlar")
def send_mashqlar(message):
    bot.reply_to(message, "Bu yerda mashqlarni bajarishingiz mumkin.")

@bot.message_handler(func=lambda message: message.text == "⚙️ Sozlamalar")
def send_sozlamalar(message):
    bot.reply_to(message, "Bu yerda sozlamalarni o'zgartirishingiz mumkin.")

@bot.message_handler(func=lambda m: True)
def echo_all(message):
    bot.reply_to(message, message.text)

bot.infinity_polling()